export interface Filiere{
    id:number;
    nomFiliere:String;
    population:string;
    group:string;
    UnitEnseignement:string;
}